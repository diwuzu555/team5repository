CREATE DATABASE issue;

USE issue;

SELECT * FROM user; 

CREATE TABLE user( 
id int(11) primary key auto_increment,
uid varchar(20),
name varchar(15),
email varchar(30),
password varchar(20)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into user(id,uid,name,email,password) value(1,'root','root','root','root');