package com.issue.springboot.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.issue.springboot.bean.User;

@Mapper
public interface UserMapper {
	//@Mapper或者@MapperScan将接口扫描装配到容器中
	    public User getUserById(Integer id);

	    public void insertUser(User user);
	    
	    public void updateUser(User user);
	    
	    public void deleteUser(Integer id);
	    
//	          登陆后显示所有用户信息
		public User loginQuery(User user);
//		插入一条用户信息，返回状态
		public int insertQuery(User user);
}
