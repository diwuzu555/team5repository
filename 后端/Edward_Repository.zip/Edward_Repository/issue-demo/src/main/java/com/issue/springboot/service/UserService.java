package com.issue.springboot.service;

import org.apache.ibatis.annotations.Mapper;
import com.issue.springboot.bean.User;

@Mapper
public interface UserService {

    User loginQuery(User user);

    int insertQuery(User user);
  
}
