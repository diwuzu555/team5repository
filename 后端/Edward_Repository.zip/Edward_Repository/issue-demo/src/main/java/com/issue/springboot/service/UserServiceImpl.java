package com.issue.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.issue.springboot.bean.User;
import com.issue.springboot.mapper.UserMapper;

public class UserServiceImpl implements UserService {

	 @Autowired
	    UserMapper userMapper;
	//登录
	    @Override
	    public User loginQuery(User user) {
//	        返回Mapper层的查询结果
	        return userMapper.loginQuery(user);
	    }
//	    注册
	    @Override
	    public int insertQuery(User user) {
	        return userMapper.insertQuery(user);
	    }

}
