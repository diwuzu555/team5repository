# DemoMybatis
基于springboot+mybatis+mysql完成增删改查

工具:idea

数据库：mysql5.7      项目中有demomybatis.sql文件其中有sql语句

修改项目中application.yml 填入自己的数据库密码 和地址  运行即可



保存

![avatar](/img/save.png) 

 查看![avatar](/img/index.png) 

修改

 ![avatar](img/update.png) 

修改后

 ![avatar](/img/index2.png) 

删除

 ![avatar](/img/delete.png) 