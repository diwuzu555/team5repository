package com.glc.demo.user.service;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.glc.demo.user.dao.IssueDao;
import com.glc.demo.user.entity.IssueEntity;

@Service
public class IssueServiceImpl implements IssueService{

	@Autowired
    IssueDao issueDao;
    
    @Override
    public List<IssueEntity> listIssue(Map map) {
        return issueDao.listIssue();
    }

    //删除issue
    @Override
    public void deleteIssue(Integer issueId) {
        issueDao.deleteIssue(issueId);
    }

    //创建issue
    @Override
    public void insertIssue(IssueEntity issue) {
        issue.setiCreateTime(new Date());
        issue.setIssueStatus("未解决");
        issueDao.insertIssue(issue);
    }

    //查询issue
    @Override
    public List<IssueEntity> queryIssue(String issueId,String issueStatus,String founder,String reviser,Date iCreateTime1,Date iCreateTime2,Date actualTime1,Date actualTime2) {
//    	issue.setiCreateTime1("1000/01/01");
//    	issue.setiCreateTime2("9999/12/31");
        return issueDao.queryIssue(issueId,issueStatus,founder,reviser,iCreateTime1,iCreateTime2,actualTime1,actualTime2);
    }

    //更新issue
    @Override
    public void updateIssue(IssueEntity issue) {
    	issue.setActualTime(new Date());
        issueDao.updateIssue(issue);
    }
    
    //查询issue报表
    @Override
    public List<IssueEntity> formIssue(String userId1,String founder) {
        return issueDao.formIssue(userId1,founder);
    }

}
