package com.glc.demo.user.service;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;

import com.glc.demo.user.entity.IssueEntity;

public interface IssueService {

	List<IssueEntity> listIssue(Map map);

    //创建issue
    public void insertIssue(IssueEntity issue);

    //查询issue
    public List<IssueEntity> queryIssue(String issueId,String issueStatus,String founder,String reviser,Date iCreateTime1,Date iCreateTime2,Date actualTime1,Date actualTime2);

    //修改issue
    public void updateIssue(@RequestBody IssueEntity issue);
    
    //删除issue
    public void deleteIssue(Integer issueId);
    
    //查询issue报表
    public List<IssueEntity> formIssue(String userId1,String founder);
}
